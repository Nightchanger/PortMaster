BLOOD.INI
*.art
*.MAP
*.dem
*.DAT
*.RFF
*.SMK
*.WAV